<h3>1. Brazylia, Kraj Przyszłości?</h3>

Wydana i napisana przez Polaków w 2016 roku książka jest wielopoziomową analizą kraju, ktora z powodzeniem może slużyc jako alternatywny przewodnik dla bardziej ambitnych.

<h3>2. Droga Do Rio</h3>

Książka to zbiór historii Polaków, którzy w trakcie (lub tuż po II wojnie światowej) wyemigrowali do Brazylii. Próżno szukać tu obrazu nowoczesnej Brazylii, a duża część historii postaci dotyczy perypetii związanych z wojną, niemniej spisane przez autorkę historie są interesujące i pozwalają lepiej zrozumieć polską powojenną emigrację.

<h3>3. Radykalne Miasta</h3>

Książka traktuje o próbach organizacji przestrzeni mieszkaniowej dla najuboższych mieszkańców metropolii Ameryki Łacińskiej. Poświęcony Brazylii rozdział dotyczy Rio de Janeiro, które boryka się z problematycznymi fawelami.

<h3>4. Ameryka Łacińska - Dzieje i Kultura</h3>

Zgrabne i przystępne podsumowanie dziejów Ameryki Łacińskiej, w tym Brazylii.

<h3>5. Kret Rewolucji</h3>

Historia i analiza ruchów lewicowych w Ameryce Łacińskiej.