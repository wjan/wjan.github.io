<h4>Najbogatsze kraje Ameryki Południowej wg PKB:</h4>

<ol>
<li>Brazylia (3 330 461	mln USD)</li>
<li>Argentyna (952 464 mln USD)</li>
<li>Kolumbia (747 024 mln USD)</li>
</ol>

<h4>Najbogatsze kraje Ameryki Południowej wg PKB na mieszkańca:</h4>

<ol>
<li>Chile (25 425,40 USD)</li>
<li>Urugwaj (23 504,44 USD)</li>
<li>Argentyna (21 370,26 USD)</li>
</ol>

<h4>Najbiedniejsze kraje Ameryki Południowej wg PKB:</h4>

Urugwaj pojawił się już wcześniej, ale jako najbogatszy kraj wg PKB na mieszkańca. Ze względu na swój niewielki rozmiar (około 3 mln mieszkańców, to najmniejszy kraj hiszpańskojęzycznej Ameryki Południowej) jest również na liście najbiedniejszych krajów kontynentu. 

<ol>
<li>Paragwaj (72 137 mln USD)</li>
<li>Urugwaj (82 406 mln USD)</li>
<li>Boliwia (88 529 mln USD)</li>
</ol>

<h4>Najbiedniejsze kraje Ameryki Południowej wg PKB na mieszkańca:</h4>

<ol>
<li>Boliwia (7 870,77 USD)</li>
<li>Paragwaj (10 227,86 USD)</li>
<li>Ekwador (11 0036 USD)</li>
</ol>