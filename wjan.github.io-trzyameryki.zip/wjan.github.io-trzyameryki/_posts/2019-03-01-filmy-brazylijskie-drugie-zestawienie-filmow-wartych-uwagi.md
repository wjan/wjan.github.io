To już drugie zestawienie produkcji genialnej kinematografii brazylijskiej. 
<a href="kultura/kino-brazylijskie/">Lista polecanych wcześniej filmów znajduje się tutaj.</a>

<h3>1. Bóg Jest Brazylijczykiem (Deus É Brasileiro, 2003)</h3>

<iframe width="560" height="315" src="https://www.youtube.com/embed/CqWHi3rHWsQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<h3>2. Dworzec Nadziei (Central do Brasil, 1998)</h3>

Film o perypetiach chłopca, który wraz z matką emigruje z biednego północnego-wschodu na południe kraju.

<iframe width="560" height="315" src="https://www.youtube.com/embed/ue8kjjTlKC0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<h3>3. Wielki Dom (Casa Grande, 2014)</h3>

Obyczajowy film o brazylijskiej rodzinie z klasy średniej-wyższej, która napotyka na problemy finansowe.

<iframe width="560" height="315" src="https://www.youtube.com/embed/lVxMtz0p0-k" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<h3>4. W Cieniu Słońca (Abril Despedaçado, 2001)</h3>

Fascynujący dramat opowiadający o dwóch skłóconych ze sobą rodzinach. Akcja filmy rozgrywa się w sertão, czyli mitycznym, półpustynnym regionie w północno-wschodniej części kraju. 

<iframe width="560" height="315" src="https://www.youtube.com/embed/cAE70tigCss" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

