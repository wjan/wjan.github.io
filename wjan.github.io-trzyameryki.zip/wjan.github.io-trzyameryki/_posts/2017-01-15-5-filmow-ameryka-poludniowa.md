<h3>1. Abrazo de la Serpiente (Kolumbia)</h3>
Historia dwóch niemieckich badaczy, którzy zapuścili się do kolumbijskiej Amazonii celem odnalezienia okazu pewnej endemicznej rośliny. Laureat Oscara z 2016 urzeka niepowtarzalną atmosferą, która miejscami przypomina "Czas Apokalipsy".

<iframe width="560" height="315" src="https://www.youtube.com/embed/FdOYd-21qaA" frameborder="0" allowfullscreen></iframe>

<h3>2. Estomago (Brazylia)</h3>
Połączenie dramatu z typowym dla Brazylii humorem w ciekawej i zaskakującej realizacji. Kolejny przykład dojrzałości brazylijskiej kinematografii. 

<iframe width="560" height="315" src="https://www.youtube.com/embed/lnloYTu5xKE" frameborder="0" allowfullscreen></iframe>

<h3>3. Cuento Chino (Argentyna)</h3>
Zabawna i wzruszająca historia pewnego młodego chińskiego imigranta, który przybywając do Argentyny próbuje odnaleźć swoich krewnych. Główna rola Ricardo Darina jest wystarczającą rekomendacją.

<iframe width="560" height="315" src="https://www.youtube.com/embed/CEyMaQu_lTU" frameborder="0" allowfullscreen></iframe>

<h3>4. No (Chile)</h3>
Film porusza temat przemian politycznych i społecznych, które miały miejsce w Chile w późnych latach osiemdziesiątych, tuż przed zakończeniem dyktatury Augusto Pinocheta. 

<iframe width="560" height="315" src="https://www.youtube.com/embed/dVQp7EKbCJU" frameborder="0" allowfullscreen></iframe>

<h3>5. Top Gear - Odcinek Specjalny: Boliwia (Wielka Brytania)</h3>
Tego programu chyba nie trzeba nikomu specjalnie przedstawiać. W odcinku specjalnym bohaterowie wyruszają z boliwijskiej dżungli, aż po Pacyfik (Sezon 14, odcinek 6).

<iframe width="560" height="315" src="https://www.youtube.com/embed/HFdfpgJq9GU" frameborder="0" allowfullscreen></iframe>

<b>Spodobało ci się nasze zestawienie? Koniecznie zatem sprawdź <a href="http://backpackista.com/pl/filmy-ameryka-poludniowa/" target="_blank">inne ciekawe filmy o Ameryce Łacińskiej</a>.</b>