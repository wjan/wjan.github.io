<h3>1. Biały Słoń (Elefante Blanco, Argentyna, 2013)</h3>

<iframe width="560" height="315" src="https://www.youtube.com/embed/2el1OiOR-c4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<h3>2. Miasto Boga (Cidade de Deus, Brazylia/Francja, 2002)</h3>

<iframe width="560" height="315" src="https://www.youtube.com/embed/nBWtTrLxUjM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<h3>3. Elitarni (Tropa de Elite, Brazylia, 2007)</h3>

<iframe width="560" height="315" src="https://www.youtube.com/embed/_V_nZNWPYQk" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>