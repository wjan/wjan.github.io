<b>Autor najlepszego w moim mniemaniu podróżniczo-muzycznego obrazka Ameryki Łacińskiej, Manu Chao (czyli José-Manuel Thomas Arthur Chao) wcale nie jest latynosem!</b> 

Francuz o hiszpańskim pochodzeniu był jednak mocno wspierany przez swoich kolegów z zespołu (już latynosów). W swoich podróżach po Ameryce Łacińskiej muzycy szukali lokalnych brzmień wśród knajpianych zespołów czy ulicznych grajków. Tutaj akurat nie ma w tym nic dziwnego, bo w Ameryce Łacińskiej nawet uliczny grajek potrafi zadziwić swoim warsztatem!. 

Tym samym grupa stworzyła wiele ciekawych i żywych brzmień przywołujących atmosferę Ameryki Południowej i Centralnej. Proste, rytmiczne i często "niekończące się" piosenki przywołują tematy bliskie zwykłemu człowiekowi. Zgodnie z wiecznie aktualnym w regionie, zorientowanym na lewą stronę sceny politycznej trendem Manu Chao śpiewa o życiu codziennym tych nieuprzywilejowanych, o wolności, miłości, szalonych i spontanicznych podróżach, czy walce o lepsze jutro. 

<iframe width="560" height="315" src="https://www.youtube.com/embed/TqXMQVNiedQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>