<h4>Intoxicados - Las Cosas Que No Se Tocan</h4>

Piosenka broni sama siebie, mocne rockowe brzmienie.

<iframe width="560" height="315" src="https://www.youtube.com/embed/zVElV7fSNpk" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>

<h4>Fito Páez - El diablo de tu corazon</h4>

Kolejny rockowy klasyk.

<iframe width="560" height="315" src="https://www.youtube.com/embed/ojOUfv_UT8w" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>

<h4>José Larralde - Quimey Neuquén</h4>

Przyklad folkloru w nowoczesnym remiksie. 

<iframe width="560" height="315" src="https://www.youtube.com/embed/yJGL1hdl8Cw" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>

<h4>Faauna - Llegamos</h4>

Jeden z moich ulubionych zespolow, polaczenie reggae, dub i rapu.

<iframe width="560" height="315" src="https://www.youtube.com/embed/Z6B0gY3cXSo" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>

<h4>Onda Vaga - Tatarali</h4>

Onda Vaga gra wylacznie akustycznie, muzyka z dusza i dobra energia.

<iframe width="560" height="315" src="https://www.youtube.com/embed/d_kLMU3MMTI" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>