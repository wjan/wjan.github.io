Ostatnie tygodnie mijają mi na poznawaniu kultury Latynosów mieszkających w USA, tym samym wyszukuję filmy, których akcja rozgrywa się w Stanach Zjednoczonych, a ich bohaterami są m.in. Latynosi.

<h3>1. Scarface</h3>

Film sensacyjny, klasyk z lat 80-tych. Kubański imigrant, uchodźca z reżimu Fidela Castro dociera do Miami żeby budować swoje narko-imperium. 

<iframe width="560" height="315" src="https://www.youtube.com/embed/7pQQHnqBa2E" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<h3>2. Trzy pogrzeby Melquiadesa Estrady</h3>

Texas, ranczerzy i przepiękne widoki pogranicze Stanów Zjednoczonych i Meksyku. Przyjaciel zamordowanego meksykanina chcąc oddać mu cześć odbywa trudną podróż przez pustkowia i pustynie.

<iframe width="560" height="315" src="https://www.youtube.com/embed/mpQsgSBEaQY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<h3>3. La Mission</h3>

Film obyczajowy, który przedstawia kulturę Chicano (po polsku "Czikano", tym mianem określa się Meksykanów mieszkających w USA). Akcja filmu rozgrywa się w San Francisco i opowiada o meksykańskiej rodzinie i wyzwaniom w dobie zmieniających się czasów. 

<iframe width="560" height="315" src="https://www.youtube.com/embed/KTkVM3nCnAs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>