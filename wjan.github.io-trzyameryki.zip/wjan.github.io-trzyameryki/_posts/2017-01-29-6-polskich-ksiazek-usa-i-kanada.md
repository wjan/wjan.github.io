<h3>1. Asfaltowy Saloon (Waldemar Łysiak)</h3>

Książka drogi. Autor wraz ze swoim przyjacielem kupuje używany samochód i wyrusza w podróż po Stanach Zjednoczonych. Barwne opisy odwiedzanych miejsc uzupełnione są ich historią. Książka nadaje się na dobry, alternatywny przewodnik po USA.

<h3>2. Wałkowanie Ameryki (Marek Wałkuski)</h3>

Kompendium wiedzy o Stanach Zjednoczonych. 

<h3>3. Odkrywanie Ameryki. Zapiski w Jeepie (Mariusz Max Kolonko)</h3>

Kilka luźno ze sobą powiązanych reportaży w formie książki podróżniczej. Kolonko odwiedza ciekawe miejsca i analizuje wydarzenia z najnowszej historii Stanów Zjednoczonych.  

<h3>4. Wyspa Na Prerii (Wojciech Cejrowski)</h3>

W swojej najnowszej książce Cejrowski w barwny i zabawny sposób opowiada o zwyczajach na amerykańskiej prowincji.

<h3>5. Kanada Pachnąca Żywicą (Arkady Fiedler)</h3>

książka opowiadająca o podróży autora do Kanady w latach 30. ubiegłego wieku.

<h3>6. Dolorado (Edward Redliński)</h3>

Nowy Jork w oczach mieszkańca polskiej prowincji, który wraz z boomem imigracyjnym lat 70. i 80. przybywa do USA.