<h3>1. Easy Rider</h3>

Para outsiderów z Los Angeles ubija kokainowy interes swojego życia i wyrusza na poszukiwanie lepszego życia po drugiej stronie USA. Pozycja obowiązkowa nie tylko dla fanów filmów drogi, ale również dla miłośników motocykli.

<iframe width="560" height="315" src="https://www.youtube.com/embed/J1cDECkN2xg" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe>

<h3>2. Into The Wild</h3>

Oparty na faktach film o wolnościowych ambicjach chłopaka, który porzuca swoje dotychczasowe życie i wyrusza na autostopową włóczęgę po USA.

<iframe width="560" height="315" src="https://www.youtube.com/embed/g7ArZ7VD-QQ" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe>

<h3>3. Znikający Punkt</h3>

Być może ten film to tylko pełnometrażowa reklamówka Dodga Challengera, jednak produkcja ma coś w sobie i zdecydowanie warto się z nią zapoznać. 

<iframe width="560" height="315" src="https://www.youtube.com/embed/9sn1w1yJKKE" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe>